document.addEventListener('DOMContentLoaded', () => {
    // FAQ Accordion
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    
    accordionHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const isActive = item.classList.contains('active');
            
            // Close all items
            document.querySelectorAll('.accordion-item').forEach(i => {
                i.classList.remove('active');
            });
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });

    // Pricing Toggle
    const billingToggle = document.getElementById('billing-toggle');
    const priceAmounts = document.querySelectorAll('.amount');
    const periodTexts = document.querySelectorAll('.period');
    const saveMessages = document.querySelectorAll('.save-msg');

    if (billingToggle) {
        billingToggle.addEventListener('change', () => {
            const isYearly = billingToggle.checked;
            
            priceAmounts.forEach(amount => {
                const monthly = amount.getAttribute('data-monthly');
                const yearly = amount.getAttribute('data-yearly');
                
                // Animate value change
                let startValue = parseInt(amount.innerText);
                let endValue = isYearly ? parseInt(yearly) : parseInt(monthly);
                
                animateValue(amount, startValue, endValue, 300);
            });

            periodTexts.forEach(period => {
                period.innerText = isYearly ? '/mês (faturado anualmente)' : '/mês';
            });

            saveMessages.forEach(msg => {
                msg.style.visibility = isYearly ? 'visible' : 'hidden';
                msg.style.opacity = isYearly ? '1' : '0';
            });
        });
    }

    // Simple value animation function
    function animateValue(obj, start, end, duration) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            obj.innerHTML = Math.floor(progress * (end - start) + start);
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }

    // Sticky Header and Reveal on Scroll
    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.style.padding = '10px 0';
            header.style.boxShadow = '0 5px 20px rgba(0,0,0,0.1)';
        } else {
            header.style.padding = '20px 0';
            header.style.boxShadow = '0 2px 10px rgba(0,0,0,0.05)';
        }
    });

    // Mobile Menu (Simple Alert for demo)
    const mobileMenuIcon = document.querySelector('.mobile-menu-icon');
    if (mobileMenuIcon) {
        mobileMenuIcon.addEventListener('click', () => {
            const navLinks = document.querySelector('.nav-links');
            const navAuth = document.querySelector('.nav-auth');
            
            // Toggle visibility logic could go here
            // For this demo, we'll just show a message
            alert('Menu mobile acionado! Em uma versão real, aqui abriria um menu lateral ou dropdown.');
        });
    }

    // Smooth Reveal Animation on Scroll
    const revealElements = document.querySelectorAll('.feature-card, .price-card, .testimonial-card');
    
    const revealOnScroll = () => {
        const triggerBottom = window.innerHeight * 0.8;
        
        revealElements.forEach(el => {
            const elTop = el.getBoundingClientRect().top;
            
            if (elTop < triggerBottom) {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }
        });
    };

    // Initial styles for reveal
    revealElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease-out';
    });

    window.addEventListener('scroll', revealOnScroll);
    revealOnScroll(); // Run once on load
});